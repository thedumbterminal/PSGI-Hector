# PSGI::Hector

[![Build Status](https://travis-ci.org/thedumbterminal/PSGI-Hector.svg?branch=master)](https://travis-ci.org/thedumbterminal/PSGI-Hector)

Simple web framework based on PSGI.

For a simple example:

1. Run `plackup script/hector_hello.psgi`
1. connect to [http://localhost:5000/](http://localhost:5000/)

Please send all feedback/bug reports to dumb@cpan.org
